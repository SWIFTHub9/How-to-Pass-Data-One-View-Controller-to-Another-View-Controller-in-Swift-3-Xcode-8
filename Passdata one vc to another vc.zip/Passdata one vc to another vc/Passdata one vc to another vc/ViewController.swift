//
//  ViewController.swift
//  Passdata one vc to another vc
//
//  Created by Abhishek Verma on 01/06/17.
//  Copyright © 2017 Abhishek Verma. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var entertext: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func Gooo(_ sender: Any) {
        performSegue(withIdentifier: "go", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let secondvc = segue.destination as! second_view_controller_class
        secondvc.passdatashow = entertext.text!
    }


}

